const OPCUAClient = require('node-opcua');
const Metodo_OPCUA = require('../controllers/riopele40_opcua_metodos');
const async = require('async');

const options = {
    applicationName: "MyClient",
    connectionStrategy: {
        initialDelay: 1000,
        maxRetry: 1
    },
    securityMode: OPCUAClient.MessageSecurityMode.None,
    securityPolicy: OPCUAClient.SecurityPolicy.None,
    //endpoint_must_exist: false,
    endpointMustExist: false,
};

const client = OPCUAClient.OPCUAClient.create(options);
let session = null;
const endpointUrl = "opc.tcp://SRVRIOT03:48012";

async function browse() {
    const browseResult = await session.browse("RootFolder");

    let result = [];

    for(const reference of browseResult.references) {
        result.push(reference);
    }
    return result;
}

async function disconnect(client) {
    await client.disconnect();
    console.log("disconnected!");
}

async function connect() {
    try {
        await client.connect(endpointUrl);
        console.log("connected!");
        session = await client.createSession();
        console.log("session created!");
    } catch(err) {
    console.log("An error has occured : ",err);
    }
}

// READ EVENTOS (DONE)

function ReadEvento(callback) {
    let stack = [];
    let node_ID = '';
    let node_ID_obj = null;
    valores_obtidos = [];

    Metodo_OPCUA.getMetodos((resultado) => {

        resultado.forEach(metodo => {
            //console.log(metodo);
            stack.push((callback) => {
                node_ID = metodo.prefixo + "ContinuosOlifil.113-101" + metodo.identificador;

                node_ID_obj =  {
                    nodeId: node_ID
                };

                session.read(node_ID_obj).then((dataValue) => {
                    data_obj = {
                        nodeId: node_ID_obj.nodeId,
                        value: dataValue.value.value,
                        tipo:metodo.tipo

                    }
                    valores_obtidos.push(data_obj)
                    return callback();
                }).catch((error) => {
                    return callback();
                })
            })
        })
        async.waterfall(stack, () => {
            return callback();
        })
    })

}

exports.Ler_eventos = function (callback) {
    connect().then(() => {
        ReadEvento((res) => {
              return callback (valores_obtidos)
        })
    });
}


// SET EVENTOS (Done em massa, falta através de SQL)

function SetEvento(callback) {
    let node_ID=''

    Metodo_OPCUA.setMetodos((evento) => {
        evento.forEach(metodo => {
            //console.log(metodo);
            node_ID = metodo.prefixo + "ContinuosOlifil.113-101" + metodo.identificador
            //console.log(metodo.tipo)
            //stack.push(node_ID,metodo.tipo)

            if (metodo.tipo =='int16'){
                var nodeToWrite = [
                    {
                        nodeId: node_ID,
                        attributeId: OPCUAClient.AttributeIds.Value,
                        value: {
                            value: {
                                dataType: OPCUAClient.DataType.Int16,
                                value: 16
                            }
                        }
                    }
                ];
                session.write(nodeToWrite, function(err,statusCode,diagnosticInfo) {
                    if (!err) {
                        //console.log(" write ok" );
                        // console.log(diagnosticInfo);
                        // console.log(statusCode);
                    } else{
                        return erro;
                    }
                });
                }
            else if (metodo.tipo =='int32'){
                var nodeToWrite = [
                    {
                        nodeId: node_ID,
                        attributeId: OPCUAClient.AttributeIds.Value,
                        value: {
                            value: {
                                dataType: OPCUAClient.DataType.Int32,
                                value: 32
                            }
                        }
                    }
                ];
                session.write(nodeToWrite, function(err,statusCode,diagnosticInfo) {
                    if (!err) {
                        //console.log(" write ok" );
                        // console.log(diagnosticInfo);
                        // console.log(statusCode);
                    } else{
                        return erro;
                    }
                });
                }
            else if (metodo.tipo =='string'){
                var nodeToWrite = [
                    {
                        nodeId: node_ID,
                        attributeId: OPCUAClient.AttributeIds.Value,
                        value: {
                            value: {
                                dataType: OPCUAClient.DataType.String,
                                value: 'string'
                            }
                        }
                    }
                ];
                session.write(nodeToWrite, function(err,statusCode,diagnosticInfo) {
                    if (!err) {
                    // console.log(" write ok" );
                    // console.log(diagnosticInfo);
                    // console.log(statusCode);
                    } else{
                        return erro;
                    }
                });
                }
        else if (metodo.tipo =='uint32'){
            var nodeToWrite = [
                {
                    nodeId: node_ID,
                    attributeId: OPCUAClient.AttributeIds.Value,
                    value: {
                        value: {
                            dataType: OPCUAClient.DataType.UInt32,
                            value: 34
                        }
                    }
                }
            ];
                session.write(nodeToWrite, function(err,statusCode,diagnosticInfo) {
                    if (!err) {
                        //console.log(" write ok" );
                        // console.log(diagnosticInfo);
                        // console.log(statusCode);
                    } else{
                        return erro;
                    }
                });
                }
            else if (metodo.tipo =='uint 16'){
                var nodeToWrite = [
                    {
                        nodeId: node_ID,
                        attributeId: OPCUAClient.AttributeIds.Value,
                        value: {
                            value: {
                                dataType: OPCUAClient.DataType.UInt16,
                                value: 17
                            }
                        }
                    }
                ];
                session.write(nodeToWrite, function(err,statusCode,diagnosticInfo) {
                    if (!err) {
                        //console.log(" write ok" );
                        // console.log(diagnosticInfo);
                        // console.log(statusCode);
                    } else{
                        return erro;
                    }
                });
            }
            
            // return callback()
        },
        
        )})
        console.log('Done')
}

exports.Set_eventos = function (evento) {
    connect().then(() => {
        SetEvento((res) => {
            return callback ()
        })
    });
}

// CYCLE NOVO EVENTO (DONE)
async function CycleEvento(callback) {
    //Metodo_OPCUA.CycleMetodos((evento) => {
        var evento = [
            {nodeId: "NodeID;ns=4;s=ContinuosOlifil.113-101.Generic.Eventos_Codigo"}
        ];
        
        let dados_evento = await session.read(evento);
        let Value = await dados_evento.map(result => result.value.value);
    
        if(Value[0]>0){
            console.log('ok');
            while (Value[0]>0){
                console.log(Value[0]);
                var nodeToWrite = [
                    {
                        nodeId: "NodeID;ns=4;s=ContinuosOlifil.113-101.Generic.Eventos_Novo",
                        attributeId: OPCUAClient.AttributeIds.Value,
                        value: { 
                            value: { 
                                dataType: OPCUAClient.DataType.Int16,
                                value: 0
                            }
                        }
                    }        
                ];
                session.write(nodeToWrite, function(err,statusCode,diagnosticInfo) {
                    if (!err) {
                        console.log(" write ok" );
                        // console.log(diagnosticInfo);
                        // console.log(statusCode);
                    } else{
                        return erro;
                    }
                }); 
                dados_evento = await session.read(evento);
                Value = await dados_evento.map(result => result.value.value);
            }        
        }else{
            return ("Não existe fila");
        }
}//)}

exports.Cycle_eventos = function (callback) {
    connect().then(() => {
        CycleEvento((res) => {
              return callback()
        })
    });
}