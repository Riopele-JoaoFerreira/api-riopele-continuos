var cron = require('node-cron');

exports.schedule1 = () => {
    cron.schedule('*/10 * * * * *', () => {
        console.log('running a task every 10 secondes');
      });
}

exports.schedule2 = () => {
    cron.schedule('* * * * *', () => {
        console.log('running a task every minute');
      });
}