exports.config = {

    port: 3000,

    database: 'eSales',

    username: 'acessoRD',

    password: '$r1o14;',

    host: 'srvsql05',

    dialect: 'mssql',

    seccao_torcedura: 1,

    seccao_fiacao_b: 18,

    seccao_repassagem: 19,

    seccao_olifil: 20

}